package com.example.epoojatest.Config;

import android.view.View;

public interface CategoryItemthree {
    public void onItemClick(View view, String product_id, String name, String image);
}
