package com.example.epoojatest.AdaptersandModels;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.epoojatest.Activities.ProductDetailsActivity;
import com.example.epoojatest.R;

import java.util.List;

public abstract class ImageAdapter extends PagerAdapter {
    private Context mContext;
    private List<ProductDetailsDataModel.ImageModel> mImages;

    ProductDetailsDataModel.ImageModel productmodel;


    public ImageAdapter(Context context, List<ProductDetailsDataModel.ImageModel> images) {
        mContext = context;
        mImages = images;
    }
    @Override
    public int getCount() {
        return mImages.size();
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.item_image, container, false);

        productmodel = mImages.get(position);

        ImageView imageView = view.findViewById(R.id.ivCode);
        Glide.with(mContext)
                .load( "https://www.epoojastore.in/image/"+productmodel.getUrl())
                .placeholder(R.drawable.splashbg)
                .error(R.drawable.splashbg)
                .into(imageView);

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return false;
    }

    public abstract void onItemClick(View view, String Product_id, String name, String image);
}
