package com.example.epoojatest.AdaptersandModels;

import android.view.View;
import android.widget.AdapterView;

public interface OnItemClickListener {
    void onItemClick(int position);

}
