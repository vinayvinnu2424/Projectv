package com.example.epoojatest.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.epoojatest.AdaptersandModels.AdapterImage;
import com.example.epoojatest.AdaptersandModels.ProductDetailsDataModel;
import com.example.epoojatest.AdaptersandModels.ProductDetailsModel;
import com.example.epoojatest.R;
import com.example.epoojatest.Retrofit.RetrofitBaseurl;
import com.example.epoojatest.Retrofit.RetrofitMethod;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailsActivity extends AppCompatActivity {
    ImageView img_close;

    ImageView img_heart;

    TextView txt_title2;
    TextView txt_product1;
    TextView txt_available;
    TextView txt_name;
    TextView txt_details;
    TextView txt_cost;
    TextView txt_stock;
    TextView txt_count;
    RatingBar rating_bar;
    RelativeLayout relative_minus;
    RelativeLayout relative_plus;
    CardView card_fav;
    CardView card_addcart;
    String product_id;
    String name;
    ViewPager viewPager;

    AdapterImage adapterImage;
    List<ProductDetailsDataModel.ImageModel> imageModelList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(ProductDetailsActivity.this, R.color.colorAccent));

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        if (b != null) {
            product_id = b.getString("product_id");
            name = b.getString("name");

        }

        txt_title2 = findViewById(R.id.txt_title2);
        txt_product1 = findViewById(R.id.txt_product1);
        txt_available = findViewById(R.id.txt_available);
        txt_name = findViewById(R.id.txt_name);
        txt_details = findViewById(R.id.txt_details);
        txt_count = findViewById(R.id.txt_count);
        img_close = findViewById(R.id.img_close);
        img_heart = findViewById(R.id.img_heart);
        txt_cost = findViewById(R.id.txt_cost);
        txt_stock = findViewById(R.id.txt_stock);
        rating_bar = findViewById(R.id.rating_bar);
        relative_minus = findViewById(R.id.relative_minus);
        relative_plus = findViewById(R.id.relative_plus);
        card_fav = findViewById(R.id.card_fav);
        card_addcart = findViewById(R.id.card_addcart);
        viewPager = findViewById(R.id.viewPager);

        imageModelList = new ArrayList<>();

        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {finish();
            }
        });

        Productdetails();
//        productdetailsapi();

    }
//    private void productdetailsapi() {
//        String url = "https://www.epoojastore.in/index.php?route=restapi/categories/products&id="+product_id+"&website=1&customer_id=";
//        final RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
//        StringRequest request = new StringRequest(Request.Method.GET, url, new com.android.volley.Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                try {
//                    JSONObject jsonObject = new JSONObject(response);
//                    Log.e(TAG, "onResponseresponse: "+response );
//
//                    JSONObject jns = jsonObject.getJSONObject("data");
//
//                    String product_id = jns.getString("product_id");
//                    String name = jns.getString("name");
//                    String productcode = jns.getString("productcode");
//                    String rating = jns.getString("rating");
//                    String description = jns.getString("description");
//                    String stock_status = jns.getString("stock_status");
//                    availability = String.valueOf(jns.getInt("availability"));
//                    String actualprice = jns.getString("actualprice");
//
//
//                    txt_product1.setText("Product Code: "+productcode);
//                    txt_available.setText("availability: "+availability);
//                    txt_name.setText(name);
//                    txt_details.setText(description);
//                    txt_cost.setText(actualprice);
//                    txt_stock.setText(stock_status);
//                    rating_bar.setRating(Float.parseFloat(rating));
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//        }, new com.android.volley.Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//            }
//        }){
//        };
//        request.setRetryPolicy(new DefaultRetryPolicy(
//                999999990,
//                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
//                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
//        requestQueue.add(request);
//    }


    private void Productdetails() {
        RetrofitMethod retrofitMethod = RetrofitBaseurl.getRetrofitInstance().create(RetrofitMethod.class);
        Call<ProductDetailsModel> call = retrofitMethod.getProducts(product_id, "1", "");
        call.enqueue(new Callback<ProductDetailsModel>() {
            @Override
            public void onResponse(Call<ProductDetailsModel> call, Response<ProductDetailsModel> response) {

                if (response.isSuccessful()) {
                    // Handle successful response
                    ProductDetailsModel data = response.body();

                    txt_name.setText(data.getProductDetailsDataModel().getName());
                    txt_stock.setText(data.getProductDetailsDataModel().getStock_status());
                    txt_details.setText(data.getProductDetailsDataModel().getDescription());
                    txt_cost.setText(data.getProductDetailsDataModel().getActualprice());
                    txt_available.setText(data.getProductDetailsDataModel().getAvailability());

//                    List<ProductDetailsDataModel.ImageModel> images = response.body().getProductDetailsDataModel().getImages();
//                    for (ProductDetailsDataModel.ImageModel imageData : images) {
//                        Log.d(TAG, "https://www.epoojastore.in/image/" + imageData.getUrl());
                    for (int i=0; i<data.getProductDetailsDataModel().getImages().size(); i++) {
                        imageModelList.add(data.getProductDetailsDataModel().getImages().get(i));
                    }
                    adapterImage = new AdapterImage( getApplicationContext(), imageModelList) {
                        @Override
                        public void onItemClick(View view, String Product_id, String name, String image) {

                        }
                    };
                    viewPager.setAdapter(adapterImage);

                } else {
                    // Handle error response
                    Toast.makeText(getApplicationContext(),"No Data",Toast.LENGTH_SHORT).show();
                }

            }
            @Override
            public void onFailure(Call<ProductDetailsModel> call, Throwable t) {
                // Handle failure
            }
        });
    }
}