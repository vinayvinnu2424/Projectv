package com.example.epoojatest.AdaptersandModels;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.epoojatest.R;

import java.util.List;

public abstract class AdapterImage  extends RecyclerView.Adapter {

    Context context;
    List<ProductDetailsDataModel.ImageModel> my_data;
    ProductDetailsDataModel.ImageModel productmodel;

    public AdapterImage(Context context, List<ProductDetailsDataModel.ImageModel> my_data) {
        this.my_data = my_data;
        this.context = context;


    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        AdapterImage.MenuViewHolder holder1 = (AdapterImage.MenuViewHolder) holder;
        productmodel = my_data.get(position);


        if (productmodel.getUrl() == null || productmodel.getUrl().equalsIgnoreCase("")) {
        } else {
            Glide.with(context)
                    .load( "https://www.epoojastore.in/image/"+productmodel.getUrl())
                    .placeholder(R.drawable.splashbg)
                    .error(R.drawable.splashbg)
                    .into(((AdapterImage.MenuViewHolder) holder).ivCode);
        }
    }

    @Override
    public int getItemCount() {
        return my_data.size();
    }

    public abstract void onItemClick(View view, String Product_id, String name, String image);

    private class MenuViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCode;
        public MenuViewHolder(View view) {
            super(view);
            ivCode = view.findViewById(R.id.img_pro);


        }
    }



}
